create env

virtualenv wineg

activate

